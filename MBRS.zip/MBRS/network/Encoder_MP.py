from . import *


class Encoder_MP(nn.Module):
	'''
	Insert a watermark into an image
	'''

	def __init__(self, H, W, message_length, blocks=4, channels=64, grad_cam=False):
		super(Encoder_MP, self).__init__()
		self.H = H
		self.W = W

		message_convT_blocks = int(np.log2(H // int(np.sqrt(message_length))))  # n
		message_se_blocks = max(blocks - message_convT_blocks, 1)

		self.image_pre_layer = ConvBNRelu(3, channels)  # 归一化
		self.image_first_layer = SENet(channels, channels, blocks=blocks)

		self.message_pre_layer = nn.Sequential(
			ConvBNRelu(1, channels),
			ExpandNet(channels, channels, blocks=message_convT_blocks),  # 依据channel number扩展
			SENet(channels, channels, blocks=message_se_blocks),  # SE特征提取
		)

		self.message_first_layer = SENet(channels, channels, blocks=blocks)  # image feature学习

		# print("Encoder_MP: ", grad_cam)
		if grad_cam:
			self.after_concat_layer = ConvBNRelu(3 * channels, channels)
		else:
			self.after_concat_layer = ConvBNRelu(2 * channels, channels)

		self.final_layer = nn.Conv2d(channels + 3, 3, kernel_size=1)  # 1x1卷积

	def forward(self, image, message, mask):
		# first Conv part of Encoder
		image_pre = self.image_pre_layer(image)
		intermediate1 = self.image_first_layer(image_pre)

		# Message Processor
		size = int(np.sqrt(message.shape[1]))
		message_image = message.view(-1, 1, size, size)
		message_pre = self.message_pre_layer(message_image)
		intermediate2 = self.message_first_layer(message_pre)
		# intermediate1 = torch.cat((intermediate1, mask), dim=1)
		# Mask-D: Grad_cam
		if mask is not None:

			mask = mask.expand_as(intermediate1)
			intermediate1 = torch.cat((intermediate1, mask), dim=1)

		# concatenate
		concat1 = torch.cat([intermediate1, intermediate2], dim=1)

		# second Conv part of Encoder
		intermediate3 = self.after_concat_layer(concat1)

		# skip connection
		concat2 = torch.cat([intermediate3, image], dim=1)

		# last Conv part of Encoder
		output = self.final_layer(concat2)

		return output
