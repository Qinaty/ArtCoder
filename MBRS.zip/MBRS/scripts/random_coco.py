import os, random, shutil

def Choose(source_dir, target_dir):
    source_images = os.listdir(source_dir)
    sample_images = random.sample(source_images, 250)
    for image in sample_images:
        shutil.copy(os.path.join(source_dir, image), target_dir)


if __name__=='__main__':
    source_dir = "../../datasets/DIV2K/DIV2K_ALL"
    target_dir = "../datasets_500"
    Choose(source_dir, target_dir)
