import os, random, shutil

def Choose(source_dir, target_dir, dirlist):
    source_dir_ = os.path.join(source_dir, dirlist[0])
    source_images = os.listdir(source_dir_)
    sample_images = random.sample(source_images, 100)
    for dir in dirlist:
        source_dir_ = os.path.join(source_dir, dir)
        target_dir_ = os.path.join(target_dir, dir)
        for image in sample_images:
            shutil.copy(os.path.join(source_dir_, image), target_dir_)


if __name__=='__main__':
    dirlist = ["Identity/", "Identity256/", "Identity_mask/", "Identity_mask256/"]
    source_dir = "../datasets_500_noise/"
    target_dir = "../datasets_100/"
    for dir in dirlist:
        target_dir_ = os.path.join(target_dir, dir)
        if os.path.exists(target_dir_):
            pass
        else:
            os.mkdir(target_dir_)
    Choose(source_dir, target_dir, dirlist)
