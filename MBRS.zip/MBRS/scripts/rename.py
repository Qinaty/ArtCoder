import os, random, shutil

target_dir = "../datasets_500"
dir_list = os.listdir(target_dir)
num = 0
for i in dir_list:
    oldname = target_dir + os.sep + dir_list[num]
    first, second = dir_list[num].split('.')
    newname = target_dir + os.sep + str(num) + "." + second
    num += 1
    os.rename(oldname, newname)