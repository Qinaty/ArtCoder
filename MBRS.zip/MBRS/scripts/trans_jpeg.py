from PIL import Image
import os

path = "../datasets_500_noise/Identity_mask256/"

Q = 70
for image_name in os.listdir(path):
    im = Image.open(path + image_name)
    image_name_ = image_name.split('.')[0]
    im.save("../datasets_500_noise/JPEG{}_mask256/".format(Q) + image_name_ + ".jpg", "JPEG", quality=Q)