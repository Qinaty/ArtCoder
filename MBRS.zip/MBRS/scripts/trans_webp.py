from PIL import Image
import os

path = "../datasets_500_noise/Identity_mask256/"

for image_name in os.listdir(path):
    im = Image.open(path + image_name)
    image_name_ = image_name.split('.')[0]
    im.save("../datasets_500_noise/Webp_mask256/" + image_name_ + ".webp", "WEBP")