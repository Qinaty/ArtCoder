from utils import *
# from network.Network import *
#
# from utils.load_train_setting import *
#
# from torchvision import transforms
# import torchvision.models as models

import argparse
import logging
import os
import random
import numpy as np
import torch
import torch.backends.cudnn as cudnn
# from networks.vision_transformer import SwinUnet as ViT_seg
# from trainer import trainer_synapse
from config import get_config


args = parser.parse_args()
if args.dataset == "Synapse":
	args.root_path = os.path.join(args.root_path, "train_npz")
config = get_config(args)

os.environ["CUDA_VISIBLE_DEVICES"] = "2, 3"
n_gpu = 2

if __name__ == "__main__":
	if not args.deterministic:
		cudnn.benchmark = True
		cudnn.deterministic = False
	else:
		cudnn.benchmark = False
		cudnn.deterministic = True

	random.seed(args.seed)
	np.random.seed(args.seed)
	torch.manual_seed(args.seed)
	torch.cuda.manual_seed(args.seed)

	dataset_name = args.dataset
	dataset_config = {
		'Synapse': {
			'root_path': args.root_path,
			'list_dir': './lists/lists_Synapse',
			'num_classes': 9,
		},
	}

	if args.batch_size != 24 and args.batch_size % 6 == 0:
		args.base_lr *= args.batch_size / 24
	args.num_classes = dataset_config[dataset_name]['num_classes']
	args.root_path = dataset_config[dataset_name]['root_path']
	args.list_dir = dataset_config[dataset_name]['list_dir']

	if not os.path.exists(args.output_dir):
		os.makedirs(args.output_dir)
	network = Network(config).cuda()
	# net = ViT_seg(config, img_size=args.img_size, num_classes=args.num_classes).cuda()
	# network.load_from(config)
	H = config.DATA.IMG_SIZE
	W = config.DATA.IMG_SIZE
	dataloader = Dataloader(batch_size, dataset_path, H=H, W=W)
	train_dataloader = dataloader.load_train_data()
	val_dataloader = dataloader.load_val_data()
	trainer = {'Synapse': trainer_synapse,}
	trainer[dataset_name](args, net, args.output_dir)


'''
train
'''
# Modify: Choose GPU

network = Network(H, W, message_length, noise_layers, device, batch_size, lr, attention, add_loss, grad_cam, with_diffusion, only_decoder)

dataloader = Dataloader(batch_size, dataset_path, H=H, W=W)
train_dataloader = dataloader.load_train_data()
val_dataloader = dataloader.load_val_data()

# Mask-D: grad_cam

if train_continue:
	EC_path = "results/" + train_continue_path + "/models/EC_" + str(train_continue_epoch) + ".pth"
	D_path = "results/" + train_continue_path + "/models/D_" + str(train_continue_epoch) + ".pth"
	network.load_model(EC_path, D_path)


print("\nStart training : \n\n")

for epoch in range(epoch_number):

	epoch += train_continue_epoch if train_continue else 0

	if add_loss:
		running_result = {
			"error_rate": 0.0,
			"psnr": 0.0,
			"ssim": 0.0,
			"g_loss": 0.0,
			"g_loss_on_discriminator": 0.0,
			"g_loss_on_encoder": 0.0,
			"g_loss_on_decoder": 0.0,
			"g_loss_on_mask": 0.0,
			"d_cover_loss": 0.0,
			"d_encoded_loss": 0.0
		}
	else:
		running_result = {
			"error_rate": 0.0,
			"psnr": 0.0,
			"ssim": 0.0,
			"g_loss": 0.0,
			"g_loss_on_discriminator": 0.0,
			"g_loss_on_encoder": 0.0,
			"g_loss_on_decoder": 0.0,
			"d_cover_loss": 0.0,
			"d_encoded_loss": 0.0
		}

	# Modify: record best
	# best_result = running_result

	start_time = time.time()

	'''
	train
	'''
	num = 0
	for _, images, in enumerate(train_dataloader):
		image = images.to(device)
		message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], message_length)))

		if attention:
			if add_loss:
				result, mask = network.train_attention_loss(image, message)
			else:
				result, mask = network.train_attention(image, message)
			# print(mask.shape)
		elif grad_cam:
			# Mask-D: Grad-cam
			tmp_images = images.to(device)
			mask = torch.empty_like(tmp_images)
			for id_ in range(tmp_images.shape[0]):
				tmp, _ = camera(normalize(tmp_images[id_]).unsqueeze(0))
				mask[id_] = tmp
			mask = alpha * mask
			mask = torch.sum(mask, 1, keepdim=True)
			# mask = alpha * get_grad_cam(tmp_images).to(device)
			# mask, _ = camera(normalize(image.squeeze()).unsqueeze(0))
			# mask = alpha * mask.to(device)
			result = network.train(image, message, mask) if not only_decoder else network.train_only_decoder(image, message)
		else:
			result = network.train(image, message, mask) if not only_decoder else network.train_only_decoder(image, message)

		for key in result:
			running_result[key] += float(result[key])

		num += 1

	'''
	train results
	'''
	content = "Epoch " + str(epoch) + " : " + str(int(time.time() - start_time)) + "\n"
	for key in running_result:
		content += key + "=" + str(running_result[key] / num) + ","
	content += "\n"

	with open(result_folder + "/train_log.txt", "a") as file:
		file.write(content)
	print(content)

	# '''
	# validation
	# '''
	if add_loss:
		val_result = {
			"error_rate": 0.0,
			"psnr": 0.0,
			"ssim": 0.0,
			"g_loss": 0.0,
			"g_loss_on_discriminator": 0.0,
			"g_loss_on_encoder": 0.0,
			"g_loss_on_decoder": 0.0,
			"g_loss_on_mask": 0.0,
			"d_cover_loss": 0.0,
			"d_encoded_loss": 0.0
		}
	else:
		val_result = {
			"error_rate": 0.0,
			"psnr": 0.0,
			"ssim": 0.0,
			"g_loss": 0.0,
			"g_loss_on_discriminator": 0.0,
			"g_loss_on_encoder": 0.0,
			"g_loss_on_decoder": 0.0,
			"d_cover_loss": 0.0,
			"d_encoded_loss": 0.0
		}

	start_time = time.time()

	saved_iterations = np.random.choice(np.arange(len(val_dataloader)), size=save_images_number, replace=False)
	saved_all = None

	num = 0
	for i, images in enumerate(val_dataloader):
		image = images.to(device)
		message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], message_length))).to(device)

		if add_loss:
			result, (images, encoded_images, noised_images, messages, decoded_messages, mask) = \
				network.validation_attention_loss(image, message)
		else:
			result, (images, encoded_images, noised_images, messages, decoded_messages, mask) = \
				network.validation_attention(image, message)

		for key in result:
			val_result[key] += float(result[key])

		num += 1

		# Modify: save mask
		if attention:
			if i in saved_iterations:
				if saved_all is None:
					saved_all = get_random_images_mask(image, encoded_images, noised_images, mask)
				else:
					saved_all = concatenate_images_mask(saved_all, image, encoded_images, noised_images, mask)

		elif grad_cam:
			if i in saved_iterations:
				if saved_all is None:
					saved_all = get_random_images_mask(image, encoded_images, noised_images, mask)
				else:
					saved_all = concatenate_images_mask(saved_all, image, encoded_images, noised_images, mask)
		else:
			if i in saved_iterations:
				if saved_all is None:
					saved_all = get_random_images(image, encoded_images, noised_images)
				else:
					saved_all = concatenate_images(saved_all, image, encoded_images, noised_images)

	if attention or grad_cam:
		save_images_mask(saved_all, epoch, result_folder + "images/", resize_to=(W, H))
	else:
		save_images(saved_all, epoch, result_folder + "images/", resize_to=(W, H))

	'''
	validation results
	'''
	content = "Epoch " + str(epoch) + " : " + str(int(time.time() - start_time)) + "\n"
	for key in val_result:
		content += key + "=" + str(val_result[key] / num) + ","
	content += "\n"

	with open(result_folder + "/val_log.txt", "a") as file:
		file.write(content)
	print(content)

	'''
	save model
	'''
	path_model = result_folder + "models/"
	path_encoder_decoder = path_model + "EC_" + str(epoch) + ".pth"
	path_discriminator = path_model + "D_" + str(epoch) + ".pth"
	network.save_model(path_encoder_decoder, path_discriminator)
