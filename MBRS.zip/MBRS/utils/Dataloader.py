import os
from PIL import Image
import numpy as np
import random
import torch
from torchvision import transforms
from torch.utils import data
import cv2


class Dataloader:

	def __init__(self, batch_size, path, H=224, W=224):
		self.batch_size = batch_size
		self.H = H
		self.W = W
		self.train_path = path + "train/"
		self.val_path = path + "validation/"
		self.test_path = path
		self.transform = transforms.Compose([
			transforms.ToTensor(),
			transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
		])
		self.transform_ = transforms.Compose([
			transforms.ToTensor()
		])

	def resize(self, image, W, H):
		min_rate = min(image.shape[0] / H, image.shape[1] / W)
		size = (int(image.shape[1] / min_rate), int(image.shape[0] / min_rate))
		image = Image.fromarray(np.uint8(image))
		image = image.resize(size, Image.ANTIALIAS)
		return np.array(image, dtype=np.uint8)

	def padding(self, image):

		pad_value = image.max()
		# pad the width if needed
		if image.shape[0] < self.W:
			pad_left = (self.W - image.shape[0]) // 2
			pad_right = (self.W - image.shape[0]) - pad_left
			image = np.pad(image, ((pad_left, pad_right), (0, 0), (0, 0)), 'constant', constant_values=pad_value)
		# pad the height if needed
		if image.shape[1] < self.H:
			pad_top = (self.H - image.shape[1]) // 2
			pad_bottom = (self.H - image.shape[1]) - pad_top
			image = np.pad(image, ((0, 0), (pad_top, pad_bottom), (0, 0)), 'constant', constant_values=pad_value)

		return image

	def transform_image(self, image):

		# ignore
		if image.shape[0] < self.W / 2 and image.shape[1] < self.H / 2:
			return None
		if image.shape[0] < image.shape[1] / 2 or image.shape[1] < image.shape[0] / 2:
			return None

		# gray
		if len(image.shape) == 2:
			image = image[:, :, np.newaxis].repeat(3, 2)

		# Padding / Resize
		image = self.resize(image, self.W * 1.1, self.H * 1.1)
		image = self.padding(image)

		# Modify: Fixed
		w_mid = image.shape[0] / 2
		h_mid = image.shape[1] / 2
		w_s = int(w_mid - self.W / 2)
		h_s = int(h_mid - self.H / 2)
		image = image[w_s:w_s + self.W, h_s:h_s + self.H, :]

		# Crop
		# w_pos = random.randint(0, image.shape[0] - self.W)
		# h_pos = random.randint(0, image.shape[1] - self.H)
		# image = image[w_pos:w_pos + self.W, h_pos:h_pos + self.H, :]

		# ToTensor and Normalize
		image = self.transform(image)

		return image

	def load(self, path):
		data = []
		id = 0
		for image_name in os.listdir(path):
			# get transformed image & mask
			# Modify: convert('RGB')
			image = Image.open(path + image_name)
			image = np.array(image, dtype=np.float32)

			transformed = self.transform_image(image)

			try:
				if transformed is not None:
					data.append(transformed)
					id += 1
					if id >= 1000:
						break
			except:
				print("ERROR in image : " + path + image_name)

		return data

	def load_pair(self, path, noise_type, attention, Long):
		id = 0
		data = []
		if Long:
			if attention:
				ori_path = path + "Identity_mask256/"
			else:
				ori_path = path + "Identity256/"
		else:
			if attention:
				ori_path = path + "Identity_mask/"
			else:
				ori_path = path + "Identity/"

		for image_name in os.listdir(ori_path):
			image_pair = {"name": image_name}

			# Original Encoded Images
			# image = Image.open(ori_path + image_name)
			# image = np.array(image, dtype=np.float32)
			# # print(image.shape)
			# transformed = self.transform_(image)
			# # print("trans", image.shape)
			# try:
			# 	if transformed is not None:
			# 		image_pair["original"] = transformed
			# except:
			# 	print("ERROR in image : " + path + image_name)
			# 	continue

			for key in noise_type:
				# Other Images
				image_name_ = image_name.split('.')[0]
				if key == "Webp":
					image_name_ = image_name_ + ".webp"
				elif "JPEG" in key:
					image_name_ = image_name_ + ".jpg"
				else:
					image_name_ = image_name_ + ".png"

				if Long:
					if attention:
						image = Image.open(path + key + "_mask256/" + image_name_)
					else:
						image = Image.open(path + key + "256/" + image_name_)
				else:
					if attention:
						image = Image.open(path + key + "_mask/" + image_name_)
					else:
						image = Image.open(path + key + "/" + image_name_)

				image = np.array(image, dtype=np.float32)
				# print(image.shape)
				transformed = self.transform_(image)
				transformed = transformed / 255.0 * 2 - 1

				try:
					if transformed is not None:
						image_pair[key] = transformed
				except:
					print("ERROR in image : " + path + image_name_)
					continue

			data.append(image_pair)
			id += 1
			if id >= 500:
				break

		return data

	def load_train_data(self):
		train_data = self.load(self.train_path)
		train_loader = torch.utils.data.DataLoader(train_data, batch_size=self.batch_size, shuffle=True, num_workers=0,
												   pin_memory=True)
		return train_loader

	def load_val_data(self):
		val_data = self.load(self.val_path)
		val_loader = torch.utils.data.DataLoader(val_data, batch_size=self.batch_size, shuffle=True, num_workers=0,
												 pin_memory=True)
		return val_loader

	def load_test_data(self):
		test_data = self.load(self.test_path)
		test_loader = torch.utils.data.DataLoader(test_data, batch_size=self.batch_size, shuffle=True, num_workers=0,
												 pin_memory=True)
		return test_loader

	def load_original_data_en(self):
		test_data = self.load(self.test_path)
		test_loader = torch.utils.data.DataLoader(test_data, batch_size=self.batch_size, shuffle=False, num_workers=0,
												pin_memory=True)
		return test_loader

	def load_original_data_de(self, noise_type, attention, Long):
		test_data = self.load_pair(self.test_path, noise_type, attention, Long)
		test_loader = torch.utils.data.DataLoader(test_data, batch_size=self.batch_size, shuffle=False, num_workers=0,
												pin_memory=True)
		return test_loader
